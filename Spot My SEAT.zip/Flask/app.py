from flask import Flask, render_template, request
import datetime

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    output = ""
    if request.method == 'POST':
        date = request.form['date']
        name = request.form['name']
        contactno = request.form['contactno']
        movie_choice = request.form['movie']
        quantity = int(request.form['quantity'])

        day_of_week = findDay(date)
        ticket_price, total_amount = calculate_ticket_price(day_of_week, movie_choice, quantity)

        if ticket_price is not None:
            output = (f"Thanks {name} for booking!<br>"
                      f"Total Booking Amount: {total_amount}<br>"
                      f"Enjoy your movie!")
        else:
            output = "Sorry, no booking available on that day."

    return render_template('index.html', output=output)

def findDay(date):
    day, month, year = (int(i) for i in date.split(' '))
    date_obj = datetime.datetime(year, month, day)
    days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    return days[date_obj.weekday()]

def calculate_ticket_price(day_of_week, movie_choice, quantity):
    prices = {
        "Monday": 170,
        "Tuesday": 170,
        "Wednesday": None,  # Off Day
        "Thursday": 220,
        "Friday": 300,
        "Saturday": 300,
        "Sunday": 320
    }

    if day_of_week == "Wednesday":
        return None, None  # No bookings on Wednesday

    movie_prices = {
        "1": 2.5,
        "2": 1.5,
        "3": 2.0,
        "4": 2.5
    }

    ticket_price = prices[day_of_week] * movie_prices[movie_choice]
    total_amount = ticket_price * quantity
    return ticket_price, total_amount

if __name__ == '__main__':
    app.run(debug=True)
