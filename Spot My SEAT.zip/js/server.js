const express = require('express');
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs'); 
const app = express();
const port = 3000;

app.use(bodyParser.json()); 

// Sample user data (replace with database interaction)
const users = [
  { username: 'user1', password: bcrypt.hashSync('password1', 10) }, // Hash password securely
];

app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    const user = users.find(u => u.username === username); 

    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid username' });
    }

    const isMatch = await bcrypt.compare(password, user.password); 

    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Invalid password' });
    }

    // On successful login, you might generate a JWT 
    // and send it in the response.
    res.json({ success: true, message: 'Login successful' }); 

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});