// Wait for the DOM to load before running any scripts
document.addEventListener("DOMContentLoaded", () => {
    // Dropdown Menu Functionality
    const dropdown = document.querySelector(".dropdown");
    const dropdownMenu = document.querySelector(".dropdown-menu");

    if (dropdown) {
        dropdown.addEventListener("click", () => {
            // Toggle dropdown visibility
            dropdownMenu.classList.toggle("show");
        });

        // Close dropdown when clicking outside
        document.addEventListener("click", (e) => {
            if (!dropdown.contains(e.target)) {
                dropdownMenu.classList.remove("show");
            }
        });
    }

    // Alert on Subscription Selection
    const subscriptionOptions = document.querySelectorAll(".dropdown-menu li");
    subscriptionOptions.forEach((option) => {
        option.addEventListener("click", () => {
            const selectedSubscription = option.textContent;
            alert(`You selected the ${selectedSubscription} plan!`);
        });
    });

    // Add smooth scrolling for navigation links
    const navLinks = document.querySelectorAll("nav ul li a");
    navLinks.forEach((link) => {
        link.addEventListener("click", (e) => {
            e.preventDefault();
            const targetId = link.getAttribute("href").replace(".html", "");
            const targetSection = document.getElementById(targetId);
            if (targetSection) {
                targetSection.scrollIntoView({ behavior: "smooth" });
            } else {
                window.location.href = link.getAttribute("href"); // Fallback for external pages
            }
        });
    });
});