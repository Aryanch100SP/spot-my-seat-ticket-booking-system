// Mock movie data
const movies = [
    {
        id: 1,
        title: "Avengers: Endgame",
        description: "The Avengers take a final stand against Thanos.",
        poster: "images/avengers.jpg",
    },
    {
        id: 2,
        title: "Inception",
        description: "A thief enters dreams to steal secrets and plant ideas.",
        poster: "images/inception.jpg",
    },
    {
        id: 3,
        title: "Interstellar",
        description: "Astronauts explore a wormhole in search of a new home.",
        poster: "images/interstellar.jpg",
    },
    {
        id: 4,
        title: "The Dark Knight",
        description: "Batman faces the Joker in a fight for Gotham's soul.",
        poster: "images/dark_knight.jpg",
    },
];