const movieImages = document.querySelectorAll('.movie-card img');
const theaterInfoContainer = document.getElementById('theater-info-container');
const theaterData = {
    "Avengers: EndGame": [
        { name: "PVR Cinemas", showtimes: ["10:00 AM", "1:00 PM", "4:00 PM"] },
    ],
    "Luka Chuppi 2": [
        { name: "Wave Cinemas", showtimes: ["12:00 PM", "3:00 PM", "6:00 PM"] },
    ],
};

movieImages.forEach(img => {
    img.addEventListener('click', () => {
        const movieName = img.dataset.movie;
        const theaters = theaterData[movieName];

        theaterInfoContainer.innerHTML = theaters.map(theater => `
            <div class="theater-info">
                <strong>${theater.name}</strong>
                <p>Showtimes: ${theater.showtimes.join(", ")}</p>
            </div>
        `).join("");
        theaterInfoContainer.style.display = "block";
    });
});
