from flask import Flask, render_template, request, redirect, url_for, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

with app.app_context():
    db.create_all()

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            session['user_id'] = user.id
            session['username'] = user.username
            return redirect(url_for('welcome'))
        else:
            error_message = "Invalid username or password"
            return render_template('login.html', error_message=error_message)

    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            return render_template('signup.html', error_message="Username already exists")

        new_user = User(username=username)
        new_user.set_password(password)

        try:
            db.session.add(new_user)
            db.session.commit()
            session['user_id'] = new_user.id
            session['username'] = username
            return redirect(url_for('welcome'))
        except Exception as e:
            db.session.rollback()
            return render_template('signup.html', error_message="Error creating account")

    return render_template('signup.html')

@app.route('/welcome')
def welcome():
    if 'user_id' in session:
        return render_template('succ.html', username=session['username'])
    return redirect(url_for('login'))

@app.route('/movies')
def movies():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    movie_list = [
        {"title": "Avengers: EndGame", "image": "images/endgame.jpg"},
        {"title": "Luka Chuppi 2", "image": "images/lc2.png"},
        {"title": "Higer", "image": "images/higer.png"},
        {"title": "Raone", "image": "images/raone.jpg"}
    ]
    return render_template("movies.html", movies=movie_list)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True, port=5002)
